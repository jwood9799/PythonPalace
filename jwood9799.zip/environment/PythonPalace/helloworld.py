

print("Hello, World!") 